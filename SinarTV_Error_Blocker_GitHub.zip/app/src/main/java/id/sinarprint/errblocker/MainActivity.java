package id.sinarprint.errblocker;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(32, 32, 32, 32);

        TextView title = new TextView(this);
        title.setText("SinarTV Error Blocker");
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);

        TextView info = new TextView(this);
        info.setText(
            "Aplikasi ini mencoba mendeteksi pesan Error 1305 / gagal mendapatkan alamat IP.\n\n" +
            "Jika teks error dapat dibaca oleh Android Accessibility, aplikasi mengirim perintah BACK " +
            "satu kali untuk menutup halaman tersebut.\n\n" +
            "Aplikasi tidak memperbaiki koneksi IP IndiHome dan tidak mematikan launcher bawaan."
        );
        info.setTextSize(16);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, 24, 0, 24);
        layout.addView(info);

        Button settings = new Button(this);
        settings.setText("Buka pengaturan Aksesibilitas");
        settings.setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        );
        layout.addView(settings);

        TextView note = new TextView(this);
        note.setText(
            "\nAktifkan layanan SinarTV Error Blocker. Setelah itu kembali ke YouTube untuk menguji. " +
            "Jika perintah BACK menutup YouTube, segera nonaktifkan layanan."
        );
        note.setTextSize(13);
        note.setGravity(Gravity.CENTER);
        layout.addView(note);

        setContentView(layout);
    }
}
