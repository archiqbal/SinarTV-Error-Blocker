package id.sinarprint.errblocker;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.Locale;

public class ErrorDismissAccessibilityService extends AccessibilityService {
    private long lastBackAt = 0L;
    private static final long COOLDOWN_MS = 3000L;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            return;
        }

        long now = System.currentTimeMillis();
        if (now - lastBackAt < COOLDOWN_MS) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        StringBuilder text = new StringBuilder();
        collectText(root, text, 0);

        String s = text.toString().toLowerCase(Locale.ROOT);
        boolean has1305 = s.contains("1305");
        boolean hasIpError =
            s.contains("alamat ip") ||
            s.contains("gagal mendapatkan alamat") ||
            (s.contains("indihome") && s.contains("ip"));

        if (has1305 && hasIpError) {
            lastBackAt = now;
            performGlobalAction(GLOBAL_ACTION_BACK);
        }
    }

    private void collectText(AccessibilityNodeInfo node, StringBuilder out, int depth) {
        if (node == null || depth > 30) return;

        CharSequence t = node.getText();
        if (t != null) out.append(t).append(' ');

        CharSequence d = node.getContentDescription();
        if (d != null) out.append(d).append(' ');

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                collectText(child, out, depth + 1);
                child.recycle();
            }
        }
    }

    @Override
    public void onInterrupt() {
        // No continuous feedback to interrupt.
    }
}
