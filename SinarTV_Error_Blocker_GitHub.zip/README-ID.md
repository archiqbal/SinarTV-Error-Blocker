# SinarTV Error Blocker

Proyek Android sederhana untuk menguji apakah pesan Error 1305 IndiHome pada STB dapat ditutup otomatis melalui Android Accessibility Service.

## Cara build otomatis di GitHub

1. Buat repository GitHub baru.
2. Masukkan seluruh isi folder proyek ini ke repository, dengan struktur folder tetap sama.
3. Pastikan file `.github/workflows/build-apk.yml` ikut terunggah.
4. Commit ke branch `main` (atau `master`).
5. Buka tab **Actions** di repository.
6. Pilih workflow **Build SinarTV Error Blocker APK**.
7. Tunggu sampai proses selesai dengan tanda centang hijau.
8. Buka hasil workflow, bagian **Artifacts**, lalu unduh `SinarTV-Error-Blocker-APK`.
9. Ekstrak artifact tersebut dan instal `app-debug.apk` di STB.

## Penting: tentang ZIP di GitHub

GitHub tidak mengekstrak ZIP yang diunggah sebagai file biasa. Jika hanya mengunggah `SinarTV_Error_Blocker_GitHub.zip`, GitHub akan menyimpan ZIP itu sebagai arsip dan tidak menjalankan workflow di dalamnya.

ZIP ini sudah berisi workflow build, tetapi file dan folder proyek harus berada langsung di root repository. Jika menggunakan browser HP, gunakan fitur unggah folder/file yang mempertahankan struktur direktori, atau layanan GitHub Codespaces/lingkungan git yang dapat mengekstrak arsip ke repository.

## Batasan teknis dan keselamatan

- Tidak membutuhkan ADB atau root.
- Pengguna harus mengaktifkan layanan Accessibility secara manual di pengaturan STB.
- Aplikasi hanya bekerja jika teks Error 1305 dapat dibaca melalui Accessibility.
- Jika pop-up tidak mengekspos teksnya, aplikasi tidak dapat mendeteksinya dengan metode ini.
- Jika perintah BACK menutup YouTube atau menyebabkan perilaku yang tidak diinginkan, segera nonaktifkan layanan melalui Pengaturan > Aksesibilitas.
- Aplikasi ini tidak memperbaiki penyebab jaringan Error 1305; hanya menguji penutupan dialog.
- Ini adalah build debug untuk pengujian, bukan aplikasi produksi.
